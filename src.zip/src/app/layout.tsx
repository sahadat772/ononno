import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
    title: 'Ononno',
    description: 'AI-powered lifelong learning platform',
}

export default function RootLayout({
    children,
}: {
    children: React.ReactNode
}) {
    return (
        <html lang="bn">
            <body>{children}</body>
        </html>
    )
}